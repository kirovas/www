<?php
	defined('myeshop') or die('Доступ запрещён!');
?>
<div id="footer">
<div id="block-footer">
<div id="footer-phone">

<h4>Служба поддержки</h4>
<h3>8 (800) 100-12-34</h3>

<p>
Режим работы:<br />
Будние дни: с 9:00 до 18:00<br />
Суббота, Воскресенье - выходные
</p>
</div>

<div class="footer-list">
<p>Сервис и Помощь</p>
<ul>
<li><a href="" >Как сделать заказ</a></li>
<li><a href="" >Способы оплаты</a></li>
<li><a href="" >Возврат</a></li>
<li><a href="" >Публичная оферта</a></li>
</ul>

</div>

<div class="footer-list">
<p>О Компании:</p>
<ul>
<li><a href="" >О нас</a></li>
<li><a href="" >Вакансии</a></li>
<li><a href="" >Партнерам</a></li>
<li><a href="" >Контакты</a></li>
</ul>
</div>

<div class="footer-list">
<p>О Компании:</p>
<ul>
<li><a href="" >О нас</a></li>
<li><a href="" >Вакансии</a></li>
<li><a href="" >Партнерам</a></li>
<li><a href="" >Контакты</a></li>
</ul>
</div>

<div class="footer-list">
<p>Навигация</p>
<ul>
<li><a href="index.php" >Главная страница</a></li>
<li><a href="" >Обратная связь</a></li>
</ul>
<p>Рассказать о сайте</p>

<script type="text/javascript">(function() {
          if (window.pluso)if (typeof window.pluso.start == "function") return;
          var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
          s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
          s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
          var h=d[g]('head')[0] || d[g]('body')[0];
          h.appendChild(s);
          })();</script>
        <div class="pluso" data-options="small,square,line,horizontal,nocounter,theme=08" data-services="vkontakte,odnoklassniki,facebook,twitter,google,moimir,email,print" data-background="#ebebeb"></div>

</div>

</div>
</div><!--footer-->