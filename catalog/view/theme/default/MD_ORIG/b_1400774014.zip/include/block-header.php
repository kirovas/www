<?php
	defined('myeshop') or die('Доступ запрещён!');
?>
<div class="header">
    <div id="block-header">
    	<h1 id="logo">
        	<a href="/"><img alt="Bike store" title="Bike store" src="images/logo.png"></a>
        </h1>
        <div class="header-contact">info@bikestore.ru<br> +7 950 000 0000</div>
        <div class="header-call-box">
            <a href="#">Закажите обратный<br> звонок</a>
        </div>
        <ul class="social">
            <li><a title="Мы в Вконтакте" href="#" id="vk">Мы в Вконтакте</a></li>
            <li><a title="Мы в Facebook" href="#" id="facebook">Мы в Facebook</a></li>
            <li><a title="Мы в Livejournal" href="#" id="lj">Мы в Livejournal</a></li>
            <li><a title="Мы в Twitter" href="#" id="twitter">Мы в Twitter</a></li>
        </ul>
        <div id="cart">
          <div class="heading" id="block-basket"><a href="cart.php?action=oneclick"><span id='cart-total'>В корзине <b>0</b> товаров на сумму <b>0.00 руб</b></span></a></div>
        </div>
    </div>
</div><!--header-->
<div id="header-menu">
  <ul>                             
    <li><a href="/">Главная</a></li>
    <li><a href="#">О компании</a></li>
    <li><a href="#">Каталог</a></li>
    <li><a href="#">Оплата и доставка</a></li>
    <li><a href="#">Гарантии</a></li>
    <li><a href="#">Как сделать заказ</a></li>
    <li><a href="#">Отзывы</a></li>
    <li><a href="#">Оптовым покупателям</a></li>
    <li><a href="#">Обратная связь</a></li>
  </ul>
</div><!--header-menu-->